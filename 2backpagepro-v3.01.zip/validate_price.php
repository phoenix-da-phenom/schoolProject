<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
     <script src="jquery.js"></script>
    <link rel ="stylesheet" href="bootstrap/css/bootstrap.css">
   <script src="bootstrap/js/bootstrap.js" ></script>
    <script src="//cdn.jsdelivr.net/npm/sweetalert2@11"></script> 

    <script src="sweetalert2.min.js"></script>
<link rel="stylesheet" href="sweetalert2.min.css"> 

 <link rel="stylesheet" href="style/mystyle.css" />
 
<body>
    <div>


   <div class="container">
       <div class="row">
           <div class="col-md-12">
        <div class="msgBox">
                <div class="loading">
                    <p  class="display-1"><span id="txtLoading"></span></p>
                    <p>This may take a few minutes.</p>

                   <a href="mainPage.php" class="btn btn-outline-success d-none" id="topUp">Top up</a>

             </div>
        </div>
</div>
           

        </div>
</div>

<script type="text/javascript" src="script.js"></script>
</head>
</body>
</html>