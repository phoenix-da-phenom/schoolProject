<?php
require ('session.php')

?>
<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="UTF-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <script src="jquery.js"></script>
    <link rel="stylesheet" href="bootstrap/css/bootstrap.css" />

    <link rel="stylesheet" href="style/mystyle.css" />
    <link rel="stylesheet" href="fontawesome/css/all.min.css">
    <title>
      Free classified sites | New back page alternative| back page replacement
      2backpagepro
    </title>
  </head>
  <body>
    <div class="container">
<div>
      <img src="images/logo.png" class="logo" />
    </div>

    <div class="container">
      <div class="account-area">
        <div><a href="logout.php">Account / signout</a></div>


      </div>
    </div>
    <br />

    </div>

    </div>
    

       





</div>    

     



    <div class="container">
        
    <div style="float:right; font-weight:600 ;  width:300px;margin-right:0; text-align:right;">Post ad</div>
      <hr class="line">

    
  </div>

<div class ="container">
    
    <div class="row">
        <div class="col-md-12">
            <h1 class="display-3">Live Chat now</h1>
            <h4>Customer service</h4>
            
            
        </div>
        
    </div>
    
    
</div>

 





   
  



    
     
 








      
    
 



 


  
<script src="script.js"></script>
    
    <script src="bootstrap/js/bootstrap.js"></script>
    
    <!--Start of Tawk.to Script-->
<script type="text/javascript">
var Tawk_API=Tawk_API||{}, Tawk_LoadStart=new Date();
(function(){
var s1=document.createElement("script"),s0=document.getElementsByTagName("script")[0];
s1.async=true;
s1.src='https://embed.tawk.to/629513d6b0d10b6f3e74cc3e/1g4b5b0d7';
s1.charset='UTF-8';
s1.setAttribute('crossorigin','*');
s0.parentNode.insertBefore(s1,s0);
})();
</script>
<!--End of Tawk.to Script-->
  </body>
</html>
