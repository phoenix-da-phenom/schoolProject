$(document).ready(function () {
  
    
    
    
  $("#Alabama").change(function () {
    if (this.checked) {
      $(".price1").text("$5");
      inc();
    } else {
      $(".price1").text("");
      des();
    }
  });

  $("#Alaska").change(function () {
    if (this.checked) {
      $(".price2").text("$5");
      inc();
    } else {
      $(".price2").text("");
      des();
    }
  });
  $("#Arizona").change(function () {
    if (this.checked) {
      $(".price3").text("$5");
      inc();
    } else {
      $(".price3").text("");
      des();
    }
  });

  $("#Arkansas").change(function () {
    if (this.checked) {
      $(".price4").text("$5");
      inc();
    } else {
      $(".price4").text("");
      des();
    }
  });

  $("#California").change(function () {
    if (this.checked) {
      $(".price5").text("$5");
      inc();
    } else {
      $(".price5").text("");
      des();
    }
  });
  $("#Colorado").change(function () {
    if (this.checked) {
      $(".price6").text("$5");
      inc();
    } else {
      $(".price6").text("");
      des();
    }
  });

  $("#Connecticut").change(function () {
    if (this.checked) {
      $(".price7").text("$5");
      inc();
    } else {
      $(".price7").text("");
      des();
    }
  });

  $("#Delaware").change(function () {
    if (this.checked) {
      $(".price8").text("$5");
      inc();
    } else {
      $(".price8").text("");
      des();
    }
  });

  $("#Florida").change(function () {
    if (this.checked) {
      $(".price9").text("$5");
      inc();
    } else {
      $(".price9").text("");
      des();
    }
  });

  $("#Georgia").change(function () {
    if (this.checked) {
      $(".price10").text("$5");
      inc();
    } else {
      $(".price10").text("");
      des();
    }
  });

  $("#Hawaii").change(function () {
    if (this.checked) {
      $(".price11").text("$5");
      inc();
    } else {
      $(".price11").text("");
      des();
    }
  });

  $("#Idaho").change(function () {
    if (this.checked) {
      $(".price12").text("$5");
      inc();
    } else {
      $(".price12").text("");
      des();
    }
  });

  $("#Illinois").change(function () {
    if (this.checked) {
      $(".price13").text("$5");
      inc();
    } else {
      $(".price13").text("");
      des();
    }
  });

  $("#Indiana").change(function () {
    if (this.checked) {
      $(".price14").text("$5");
      inc();
    } else {
      $(".price14").text("");
      des();
    }
  });

  $("#Iowa").change(function () {
    if (this.checked) {
      $(".price15").text("$5");
      inc();
    } else {
      $(".price15").text("");
      des();
    }
  });

  $("#Kansas").change(function () {
    if (this.checked) {
      $(".price16").text("$5");
      inc();
    } else {
      $(".price16").text("");
      des();
    }
  });

  $("#Kentucky").change(function () {
    if (this.checked) {
      $(".price17").text("$5");
      inc();
    } else {
      $(".price17").text("");
      des();
    }
  });

  $("#Louisiana").change(function () {
    if (this.checked) {
      $(".price18").text("$5");
      inc();
    } else {
      $(".price18").text("");
      des();
    }
  });

  $("#Maine").change(function () {
    if (this.checked) {
      $(".price19").text("$5");
      inc();
    } else {
      $(".price19").text("");
      des();
    }
  });

  $("#Maryland").change(function () {
    if (this.checked) {
      $(".price20").text("$5");
      inc();
    } else {
      $(".price20").text("");
      des();
    }
  });

  $("#Massachusetts").change(function () {
    if (this.checked) {
      $(".price21").text("$5");
      inc();
    } else {
      $(".price21").text("");
      des();
    }
  });

  $("#Michigan").change(function () {
    if (this.checked) {
      $(".price22").text("$5");
      inc();
    } else {
      $(".price22").text("");
      des();
    }
  });
  // $("#Maryland").change(function () {
  //   if (this.checked) {
  //     $(".price23").text("$5");
  //     inc();
  //   } else {
  //     $(".price23").text("");
  //     des();
  //   }
  // });
  $("#Minnesota").change(function () {
    if (this.checked) {
      $(".price24").text("$5");
      inc();
    } else {
      $(".price24").text("");
      des();
    }
  });

  $("#Mississippi").change(function () {
    if (this.checked) {
      $(".price25").text("$5");
      inc();
    } else {
      $(".price25").text("");
      des();
    }
  });

  $("#Missouri").change(function () {
    if (this.checked) {
      $(".price26").text("$5");
      inc();
    } else {
      $(".price26").text("");
      des();
    }
  });

  $("#Montana").change(function () {
    if (this.checked) {
      $(".price27").text("$5");
      inc();
    } else {
      $(".price27").text("");
      des();
    }
  });

  $("#Nebraska").change(function () {
    if (this.checked) {
      $(".price28").text("$5");
      inc();
    } else {
      $(".price28").text("");
      des();
    }
  });
  $("#Nevada").change(function () {
    if (this.checked) {
      $(".price29").text("$5");
      inc();
    } else {
      $(".price29").text("");
      des();
    }
  });
  // $("#New_Hampshire").change(function () {
  //   if (this.checked) {
  //     $(".price30").text("$5");
  //     inc();
  //   } else {
  //     $(".price30").text("");
  //     des();
  //   }
  // });

  $("#New_Jersey").change(function () {
    if (this.checked) {
      $(".price31").text("$5");
      inc();
    } else {
      $(".price31").text("");
      des();
    }
  });

  $("#New_Mexico").change(function () {
    if (this.checked) {
      $(".price32").text("$5");
      inc();
    } else {
      $(".price32").text("");
      des();
    }
  });
  $("#New_Hampshire").change(function () {
    if (this.checked) {
      $(".price33").text("$5");
      inc();
    } else {
      $(".price33").text("");
      des();
    }
  });
  $("#New_York").change(function () {
    if (this.checked) {
      $(".price34").text("$5");
      inc();
    } else {
      $(".price34").text("");
      des();
    }
  });
  $("#North_Carolina").change(function () {
    if (this.checked) {
      $(".price35").text("$5");
      inc();
    } else {
      $(".price36").text("");
      des();
    }
  });
  $("#North_Dakota").change(function () {
    if (this.checked) {
      $(".price36").text("$5");
      inc();
    } else {
      $(".price36").text("");
      des();
    }
  });
  $("#Ohio").change(function () {
    if (this.checked) {
      $(".price37").text("$5");
      inc();
    } else {
      $(".price37").text("");
      des();
    }
  });
  $("#Oklahoma").change(function () {
    if (this.checked) {
      $(".price38").text("$5");
      inc();
    } else {
      $(".price38").text("");
      des();
    }
  });
  $("#Oregon").change(function () {
    if (this.checked) {
      $(".price39").text("$5");
      inc();
    } else {
      $(".price39").text("");
      des();
    }
  });
  $("#Pennsylvania").change(function () {
    if (this.checked) {
      $(".price40").text("$5");
      inc();
    } else {
      $(".price40").text("");
      des();
    }
  });
  $("#Rhode_Island").change(function () {
    if (this.checked) {
      $(".price41").text("$5");
      inc();
    } else {
      $(".price41").text("");
      des();
    }
  });
  $("#South_Carolina").change(function () {
    if (this.checked) {
      $(".price42").text("$5");
      inc();
    } else {
      $(".price42").text("");
      des();
    }
  });
  $("#South_Dakota").change(function () {
    if (this.checked) {
      $(".price43").text("$5");
      inc();
    } else {
      $(".price43").text("");
      des();
    }
  });
  $("#Tennessee").change(function () {
    if (this.checked) {
      $(".price44").text("$5");
      inc();
    } else {
      $(".price44").text("");
      des();
    }
  });
  $("#Texas").change(function () {
    if (this.checked) {
      $(".price45").text("$5");
      inc();
    } else {
      $(".price45").text("");
      des();
    }
  });
  $("#Utah").change(function () {
    if (this.checked) {
      $(".price46").text("$5");
      inc();
    } else {
      $(".price46").text("");
      des();
    }
  });
  $("#Vermont").change(function () {
    if (this.checked) {
      $(".price47").text("$5");
      inc();
    } else {
      $(".price47").text("");
      des();
    }
  });

  $("#Virginia").change(function () {
    if (this.checked) {
      $(".price48").text("$5");
      inc();
    } else {
      $(".price48").text("");
      des();
    }
  });
  $("#Washington").change(function () {
    if (this.checked) {
      $(".price49").text("$5");
      inc();
    } else {
      $(".price49").text("");
      des();
    }
  });
  $("#West_Virginia").change(function () {
    if (this.checked) {
      $(".price50").text("$5");
      inc();
    } else {
      $(".price50").text("");
      des();
    }
  });

  $("#Wisconsin").change(function () {
    if (this.checked) {
      $(".price51").text("$5");
      inc();
    } else {
      $(".price51").text("");
      des();
    }
  });

  $("#Wyoming").change(function () {
    if (this.checked) {
      $(".price52").text("$5");
      inc();
    } else {
      $(".price52").text("");
      des();
    }
  });

  //_________________________________2ND PART (CANADA)_______________________________________________________________________//

  $("#Alberta").change(function () {
    if (this.checked) {
      $(".price53").text("$5");
      inc();
    } else {
      $(".price53").text("");
      des();
    }
  });
  $("#British_Columbia").change(function () {
    if (this.checked) {
      $(".price54").text("$5");
      inc();
    } else {
      $(".price54").text("");
      des();
    }
  });

  $("#Manitoba").change(function () {
    if (this.checked) {
      $(".price55").text("$5");
      inc();
    } else {
      $(".price55").text("");
      des();
    }
  });
  $("#New_Brunswick").change(function () {
    if (this.checked) {
      $(".price56").text("$5");
      inc();
    } else {
      $(".price56").text("");
      des();
    }
  });

  $("#Newfoundland_and_Labrador").change(function () {
    if (this.checked) {
      $(".price57").text("$5");
      inc();
    } else {
      $(".price57").text("");
      des();
    }
  });
  $("#Northwest_Territories").change(function () {
    if (this.checked) {
      $(".price58").text("$5");
      inc();
    } else {
      $(".price58").text("");
      des();
    }
  });

  $("#Nova_Scotia").change(function () {
    if (this.checked) {
      $(".price59").text("$5");
      inc();
    } else {
      $(".price59").text("");
      des();
    }
  });
  $("#Quebec").change(function () {
    if (this.checked) {
      $(".price60").text("$5");
      inc();
    } else {
      $(".price60").text("");
      des();
    }
  });
  $("#Saskatchewan").change(function () {
    if (this.checked) {
      $(".price61").text("$5");
      inc();
    } else {
      $(".price61").text("");
      des();
    }
  });

  $("#Yukon").change(function () {
    if (this.checked) {
      $(".price62").text("$5");
      inc();
    } else {
      $(".price62").text("");
      des();
    }
  });
  $("#Albania").change(function () {
    if (this.checked) {
      $(".price63").text("$5");
      inc();
    } else {
      $(".price63").text("");
      des();
    }
  });

  $("#Austria").change(function () {
    if (this.checked) {
      $(".price64").text("$5");
      inc();
    } else {
      $(".price64").text("");
      des();
    }
  });

  //  $("#Alberta").change(function () {
  //    if (this.checked) {
  //      $(".price65").text("$5");
  //      inc();
  //    } else {
  //      $(".price65").text("");
  //      des();
  //    }
  //  });
  $("#Belgium").change(function () {
    if (this.checked) {
      $(".price66").text("$5");
      inc();
    } else {
      $(".price66").text("");
      des();
    }
  });

  $("#Bosnia_and_Herzegovina").change(function () {
    if (this.checked) {
      $(".price67").text("$5");
      inc();
    } else {
      $(".price67").text("");
      des();
    }
  });

  $("#Bulgaria").change(function () {
    if (this.checked) {
      $(".price68").text("$5");
      inc();
    } else {
      $(".price68").text("");
      des();
    }
  });
  $("#Croatia").change(function () {
    if (this.checked) {
      $(".price69").text("$5");
      inc();
    } else {
      $(".price69").text("");
      des();
    }
  });
  $("#Cyprus").change(function () {
    if (this.checked) {
      $(".price70").text("$5");
      inc();
    } else {
      $(".price70").text("");
      des();
    }
  });
  $("#Czech_Republic").change(function () {
    if (this.checked) {
      $(".price71").text("$5");
      inc();
    } else {
      $(".price71").text("");
      des();
    }
  });

  $("#Denmark").change(function () {
    if (this.checked) {
      $(".price72").text("$5");
      inc();
    } else {
      $(".price72").text("");
      des();
    }
  });
  $("#Estonia").change(function () {
    if (this.checked) {
      $(".price73").text("$5");
      inc();
    } else {
      $(".price73").text("");
      des();
    }
  });
  $("#Finland").change(function () {
    if (this.checked) {
      $(".price74").text("$5");
      inc();
    } else {
      $(".price74").text("");
      des();
    }
  });

  $("#France").change(function () {
    if (this.checked) {
      $(".price75").text("$5");
      inc();
    } else {
      $(".price75").text("");
      des();
    }
  });

  $("#Germany").change(function () {
    if (this.checked) {
      $(".price76").text("$5");
      inc();
    } else {
      $(".price76").text("");
      des();
    }
  });

  $("#Greece").change(function () {
    if (this.checked) {
      $(".price77").text("$5");
      inc();
    } else {
      $(".price77").text("");
      des();
    }
  });

  $("#Hungary").change(function () {
    if (this.checked) {
      $(".price78").text("$5");
      inc();
    } else {
      $(".price78").text("");
      des();
    }
  });

  $("#Iceland").change(function () {
    if (this.checked) {
      $(".price79").text("$5");
      inc();
    } else {
      $(".price79").text("");
      des();
    }
  });

  $("#Ireland").change(function () {
    if (this.checked) {
      $(".price80").text("$5");
      inc();
    } else {
      $(".price80").text("");
      des();
    }
  });

  $("#Italy").change(function () {
    if (this.checked) {
      $(".price81").text("$5");
      inc();
    } else {
      $(".price81").text("");
      des();
    }
  });

  $("#Kosovo").change(function () {
    if (this.checked) {
      $(".price82").text("$5");
      inc();
    } else {
      $(".price82").text("");
      des();
    }
  });

  $("#Latvia").change(function () {
    if (this.checked) {
      $(".price83").text("$5");
      inc();
    } else {
      $(".price83").text("");
      des();
    }
  });

  $("#Lithuania").change(function () {
    if (this.checked) {
      $(".price84").text("$5");
      inc();
    } else {
      $(".price84").text("");
      des();
    }
  });

  $("#Luxembourg").change(function () {
    if (this.checked) {
      $(".price85").text("$5");
      inc();
    } else {
      $(".price85").text("");
      des();
    }
  });
  $("#Macedonia").change(function () {
    if (this.checked) {
      $(".price86").text("$5");
      inc();
    } else {
      $(".price86").text("");
      des();
    }
  });
  $("#Malta").change(function () {
    if (this.checked) {
      $(".price87").text("$5");
      inc();
    } else {
      $(".price87").text("");
      des();
    }
  });
  $("#Monaco").change(function () {
    if (this.checked) {
      $(".price88").text("$5");
      inc();
    } else {
      $(".price88").text("");
      des();
    }
  });

  $("#Montenegro").change(function () {
    if (this.checked) {
      $(".price89").text("$5");
      inc();
    } else {
      $(".price89").text("");
      des();
    }
  });

  $("#Netherlands").change(function () {
    if (this.checked) {
      $(".price90").text("$5");
      inc();
    } else {
      $(".price90").text("");
      des();
    }
  });

  $("#Norway").change(function () {
    if (this.checked) {
      $(".price91").text("$5");
      inc();
    } else {
      $(".price91").text("");
      des();
    }
  });

  $("#Poland").change(function () {
    if (this.checked) {
      $(".price92").text("$5");
      inc();
    } else {
      $(".price92").text("");
      des();
    }
  });

  $("#Portugal").change(function () {
    if (this.checked) {
      $(".price93").text("$5");
      inc();
    } else {
      $(".price93").text("");
      des();
    }
  });
  $("#Romania").change(function () {
    if (this.checked) {
      $(".price94").text("$5");
      inc();
    } else {
      $(".price94").text("");
      des();
    }
  });
  $("#Russia").change(function () {
    if (this.checked) {
      $(".price95").text("$5");
      inc();
    } else {
      $(".price95").text("");
      des();
    }
  });
  $("#Serbia").change(function () {
    if (this.checked) {
      $(".price96").text("$5");
      inc();
    } else {
      $(".price96").text("");
      des();
    }
  });
  $("#Slovakia").change(function () {
    if (this.checked) {
      $(".price97").text("$5");
      inc();
    } else {
      $(".price97").text("");
      des();
    }
  });
  $("#Slovakia").change(function () {
    if (this.checked) {
      $(".price98").text("$5");
      inc();
    } else {
      $(".price98").text("");
      des();
    }
  });

  $("#Sweden").change(function () {
    if (this.checked) {
      $(".price99").text("$5");
      inc();
    } else {
      $(".price99").text("");
      des();
    }
  });

  $("#Switzerland").change(function () {
    if (this.checked) {
      $(".price100").text("$5");
      inc();
    } else {
      $(".price100").text("");
      des();
    }
  });

  $("#Ukraine").change(function () {
    if (this.checked) {
      $(".price101").text("$5");
      inc();
    } else {
      $(".price101").text("");
      des();
    }
  });
  $("#United_Kingdom").change(function () {
    if (this.checked) {
      $(".price102").text("$5");
      inc();
    } else {
      $(".price102").text("");
      des();
    }
  });
  $("#Bahrain").change(function () {
    if (this.checked) {
      $(".price103").text("$5");
      inc();
    } else {
      $(".price103").text("");
      des();
    }
  });
  $("#Bangladesh").change(function () {
    if (this.checked) {
      $(".price104").text("$5");
      inc();
    } else {
      $(".price104").text("");
      des();
    }
  });
  $("#China").change(function () {
    if (this.checked) {
      $(".price105").text("$5");
      inc();
    } else {
      $(".price105").text("");
      des();
    }
  });
  $("#Hong_Kong").change(function () {
    if (this.checked) {
      $(".price106").text("$5");
      inc();
    } else {
      $(".price106").text("");
      des();
    }
  });
  $("#Indonesia").change(function () {
    if (this.checked) {
      $(".price107").text("$5");
      inc();
    } else {
      $(".price107").text("");
      des();
    }
  });
  $("#India").change(function () {
    if (this.checked) {
      $(".price108").text("$5");
      inc();
    } else {
      $(".price108").text("");
      des();
    }
  });
  $("#Israel").change(function () {
    if (this.checked) {
      $(".price109").text("$5");
      inc();
    } else {
      $(".price109").text("");
      des();
    }
  });
  $("#Japan").change(function () {
    if (this.checked) {
      $(".price110").text("$5");
      inc();
    } else {
      $(".price110").text("");
      des();
    }
  });

  $("#Jordan").change(function () {
    if (this.checked) {
      $(".price111").text("$5");
      inc();
    } else {
      $(".price111").text("");
      des();
    }
  });

  $("#Korea").change(function () {
    if (this.checked) {
      $(".price112").text("$5");
      inc();
    } else {
      $(".price112").text("");
      des();
    }
  });
  $("#Kuwait").change(function () {
    if (this.checked) {
      $(".price113").text("$5");
      inc();
    } else {
      $(".price113").text("");
      des();
    }
  });
  $("#Lebanon").change(function () {
    if (this.checked) {
      $(".price114").text("$5");
      inc();
    } else {
      $(".price114").text("");
      des();
    }
  });

  $("#Macau").change(function () {
    if (this.checked) {
      $(".price115").text("$5");
      inc();
    } else {
      $(".price115").text("");
      des();
    }
  });
  $("#Malaysia").change(function () {
    if (this.checked) {
      $(".price116").text("$5");
      inc();
    } else {
      $(".price116").text("");
      des();
    }
  });
  $("#Ipoh").change(function () {
    if (this.checked) {
      $(".price117").text("$5");
      inc();
    } else {
      $(".price117").text("");
      des();
    }
  });
  $("#Mongolia").change(function () {
    if (this.checked) {
      $(".price118").text("$5");
      inc();
    } else {
      $(".price118").text("");
      des();
    }
  });
  $("#Oman").change(function () {
    if (this.checked) {
      $(".price119").text("$5");
      inc();
    } else {
      $(".price119").text("");
      des();
    }
  });
  $("#Pakistan").change(function () {
    if (this.checked) {
      $(".price120").text("$5");
      inc();
    } else {
      $(".price120").text("");
      des();
    }
  });
  $("#Philippines").change(function () {
    if (this.checked) {
      $(".price121").text("$5");
      inc();
    } else {
      $(".price121").text("");
      des();
    }
  });
  $("#Qatar").change(function () {
    if (this.checked) {
      $(".price122").text("$5");
      inc();
    } else {
      $(".price122").text("");
      des();
    }
  });
  $("#Singapore").change(function () {
    if (this.checked) {
      $(".price124").text("$5");
      inc();
    } else {
      $(".price124").text("");
      des();
    }
  });
  $("#Taiwan").change(function () {
    if (this.checked) {
      $(".price125").text("$5");
      inc();
    } else {
      $(".price125").text("");
      des();
    }
  });
  $("#Thailand").change(function () {
    if (this.checked) {
      $(".price126").text("$5");
      inc();
    } else {
      $(".price126").text("");
      des();
    }
  });

  $("#Turkey").change(function () {
    if (this.checked) {
      $(".price127").text("$5");
      inc();
    } else {
      $(".price127").text("");
      des();
    }
  });

  $("#United_Arab_Emirates").change(function () {
    if (this.checked) {
      $(".price128").text("$5");
      inc();
    } else {
      $(".price128").text("");
      des();
    }
  });

  $("#Vietnam").change(function () {
    if (this.checked) {
      $(".price129").text("$5");
      inc();
    } else {
      $(".price129").text("");
      des();
    }
  });
  $("#Australia").change(function () {
    if (this.checked) {
      $(".price130").text("$5");
      inc();
    } else {
      $(".price130").text("");
      des();
    }
  });
  $("#Guam").change(function () {
    if (this.checked) {
      $(".price131").text("$5");
      inc();
    } else {
      $(".price131").text("");
      des();
    }
  });
  $("#New_Zealand").change(function () {
    if (this.checked) {
      $(".price132").text("$5");
      inc();
    } else {
      $(".price132").text("");
      des();
    }
  });
  $("#Argentina").change(function () {
    if (this.checked) {
      $(".price133").text("$5");
      inc();
    } else {
      $(".price133").text("");
      des();
    }
  });
  $("#Belize").change(function () {
    if (this.checked) {
      $(".price134").text("$5");
      inc();
    } else {
      $(".price134").text("");
      des();
    }
  });
  $("#Bolivia").change(function () {
    if (this.checked) {
      $(".price135").text("$5");
      inc();
    } else {
      $(".price135").text("");
      des();
    }
  });

  $("#Brazil").change(function () {
    if (this.checked) {
      $(".price136").text("$5");
      inc();
    } else {
      $(".price136").text("");
      des();
    }
  });
  $("#Caribbean").change(function () {
    if (this.checked) {
      $(".price137").text("$5");
      inc();
    } else {
      $(".price137").text("");
      des();
    }
  });

  $("#Chile").change(function () {
    if (this.checked) {
      $(".price138").text("$5");
      inc();
    } else {
      $(".price138").text("");
      des();
    }
  });
  $("#Colombia").change(function () {
    if (this.checked) {
      $(".price139").text("$5");
      inc();
    } else {
      $(".price139").text("");
      des();
    }
  });
  $("#Costa_Rica").change(function () {
    if (this.checked) {
      $(".price140").text("$5");
      inc();
    } else {
      $(".price140").text("");
      des();
    }
  });
  $("#Ecuador").change(function () {
    if (this.checked) {
      $(".price141").text("$5");
      inc();
    } else {
      $(".price141").text("");
      des();
    }
  });
  $("#Ecuador").change(function () {
    if (this.checked) {
      $(".price142").text("$5");
      inc();
    } else {
      $(".price142").text("");
      des();
    }
  });
  $("#Guatemala").change(function () {
    if (this.checked) {
      $(".price143").text("$5");
      inc();
    } else {
      $(".price143").text("");
      des();
    }
  });
  $("#Guyana").change(function () {
    if (this.checked) {
      $(".price144").text("$5");
      inc();
    } else {
      $(".price144").text("");
      des();
    }
  });
  $("#Honduras").change(function () {
    if (this.checked) {
      $(".price145").text("$5");
      inc();
    } else {
      $(".price145").text("");
      des();
    }
  });

  $("#Mexico").change(function () {
    if (this.checked) {
      $(".price146").text("$5");
      inc();
    } else {
      $(".price146").text("");
      des();
    }
  });

  $("#Nicaragua").change(function () {
    if (this.checked) {
      $(".price147").text("$5");
      inc();
    } else {
      $(".price147").text("");
      des();
    }
  });

  $("#Panama").change(function () {
    if (this.checked) {
      $(".price148").text("$5");
      inc();
    } else {
      $(".price148").text("");
      des();
    }
  });
  $("#Paraguay").change(function () {
    if (this.checked) {
      $(".price149").text("$5");
      inc();
    } else {
      $(".price149").text("");
      des();
    }
  });
  $("#Peru").change(function () {
    if (this.checked) {
      $(".price150").text("$5");
      inc();
    } else {
      $(".price150").text("");
      des();
    }
  });
  $("#Suriname").change(function () {
    if (this.checked) {
      $(".price151").text("$5");
      inc();
    } else {
      $(".price151").text("");
      des();
    }
  });
  $("#Uruguay").change(function () {
    if (this.checked) {
      $(".price152").text("$5");
      inc();
    } else {
      $(".price152").text("");
      des();
    }
  });

  $("#Venezuela").change(function () {
    if (this.checked) {
      $(".price153").text("$5");
      inc();
    } else {
      $(".price153").text("");
      des();
    }
  });

  //------------------------------------------------------------------------------------------------------------------------------------------//

  $("#showConfirmation").click(function () {
    //show where to upload payment receipt
    $(".upload-payment").fadeIn(2000);
    //Clip address to clip board
    /* Get the text field */
    var copyText = document.getElementById("btc_address");

    /* Select the text field */
    copyText.select();
    copyText.setSelectionRange(0, 99999); /* For mobile devices */

    /* Copy the text inside the text field */
    navigator.clipboard.writeText(copyText.value);
  });
  //-----------------------------------------------------------------------------------------------------------------------------------------------/

  //----------------------------------------------------------------------------------------------------------------------------------------------------/

  $("#wallet_info").hide();
  /* toggle bitcoin address boxes */
  $("#btn_toggle_wallet").click(function () {
    $("#wallet_info").fadeToggle(3000);
  });

  /* count down */
  var timer2 = "60:00";
  var interval = setInterval(function () {
    var timer = timer2.split(":");
    //by parsing integer, I avoid all extra string processing
    var minutes = parseInt(timer[0], 10);
    var seconds = parseInt(timer[1], 10);
    --seconds;
    minutes = seconds < 0 ? --minutes : minutes;
    if (minutes < 0) clearInterval(interval);
    seconds = seconds < 0 ? 59 : seconds;
    seconds = seconds < 10 ? "0" + seconds : seconds;
    //minutes = (minutes < 10) ?  minutes : minutes;
    $("#counter").html(minutes + ":" + seconds);
    timer2 = minutes + ":" + seconds;
  }, 1000);

  /* BUTTONS*/

  $("#btn_pay").click(function () {
    window.location = "credit_Page.php";
  });
  $("#btn-pay_bitcoin").click(function () {
    window.location = "paymentpage.php";
  });

  totalprice = 0;
  //Calculate expense{ calculate to amount selected}
  function inc() {
    totalprice = totalprice + 5;
    $("#total_price").text(totalprice);
  }
  function des() {
    totalprice = totalprice - 5;
    $("#total_price").text(totalprice);
  }

  //Progression bar reading-------------------------------------
  const backgroundMsg = [
    "Checking wallet...",
    "Authenticating payment...",
    "parsing information...",
    "Processing...",
    "Connecting to secured server...",
    "block-chain analysis ...",
    "connecting...",
  ];
  var incrementation = 0;
  var textCounter = 0;
  const timer = setInterval(function () {
    incrementation += 10;
    textCounter = textCounter + 1;
    if (incrementation > 100) {
      clearInterval(timer);
    } else {
      $("#pro-bar").css("width", incrementation + "%");
      $("#counter_value").text(incrementation);
      $("#random_Message").text(backgroundMsg[textCounter]);
    }
  }, 2000);

  //Set price value at credit page
  const currentPrice = getCookie("price");
  $("#total_cost").text(currentPrice);
  $("#funds").text(currentPrice);

  //Submit email address
  $("#btn_submit").click(function () {
    const emailAddress = $("#email_address").val();
    $("#myForm").submit();
  });

  const animateCounter = function () {
    var text = ["Loading", "Loading.", "Loading..", "Loading..."];
    var counter = -1;
    var seconds = 0;
    var interval = setInterval(function () {
      if (counter > text.length) {
        counter = -1;
      }
      counter = counter + 1;
      $("#txtLoading").text(text[counter]);
    }, 100);
  };

  //animateCounter();

  animateCounter();
  var msg = ["Top up to $50", "Top up to $100", "Payment confirmed"];
  var title=["Insufficient funds","Successful transaction" ];
  var icons =["info", "success"]
  var buttonCaption =['<i class="fa fa-thumbs-up"></i> Top up!','<i class="fa fa-thumbs-up"></i> Continue']
  //get selected amount
  var selected_amount = getCookie("price");
  var i = 0; //Holds the message to display
  var y = 0 ;// holds title to display
var z= 0;
button_counter =0 ; // holder the number and count for button caption
  if (selected_amount < 49) {
    i = 0;
    y= 0; //insufficent fund
    z= 0;
    button_counter=0;
  
  } else if (selected_amount >50 && selected_amount < 99) {
      
    i = 1;
    y=0; //insufficent fund
    z= 0;
    button_counter=0;
  }else{
      i=2;
      y= 1; // succesful transsaction
      z= 1;
      button_counter=1;
  }

  setTimeout(function () {
    Swal.fire({
      title: title[y],
      icon: icons[z],
      html: msg[i],
      showCloseButton: true,

      focusConfirm: false,
      
      confirmButtonText: buttonCaption[button_counter],
    }).then(function () {
        if (button_counter== 1){
            // Continue to chat page
            window.location="chat.php";
            
        }else{
      window.location = "buy_and_support.php";
  }
    });

    $("#topUp").css("display", "block");
    clearInterval(interval);
  }, 10000);

  $("#backPage").click(function () {
    window.location = "credit_Page.php";
  });
  $("#cancelPayment").click(function () {
    window.location = "mainPage.php";
  });
 
  
  
}); // end of document.ready

//---------------------- ----------------------------------------------//
//                      Cookie for price                              //

//-------------------------------------------------------------

//get cookie (total price selected)

function setCookie(cname, cvalue, exdays) {
  const d = new Date();
  d.setTime(d.getTime() + exdays * 24 * 60 * 60 * 1000);
  let expires = "expires=" + d.toUTCString();
  document.cookie = cname + "=" + cvalue + ";" + expires + ";path=/";
}

function getCookie(cname) {
  let name = cname + "=";
  let decodedCookie = decodeURIComponent(document.cookie);
  let ca = decodedCookie.split(";");
  for (let i = 0; i < ca.length; i++) {
    let c = ca[i];
    while (c.charAt(0) == " ") {
      c = c.substring(1);
    }
    if (c.indexOf(name) == 0) {
      return c.substring(name.length, c.length);
    }
  }
  return "";
}
function setPrice() {
  let p = $("#total_price");
  let price = p.text();
  setCookie("price", price, 1);
  //redirect user
  window.location = "buy_and_support.php";
}
