//This script is meant to handle bu and support page

document.getElementById("btn_pay").addEventListener("click", function (event) {
  event.preventDefault();
  console.log("Hello world");
});

function checkerPage(e) {
  e.preventDefault();
}
